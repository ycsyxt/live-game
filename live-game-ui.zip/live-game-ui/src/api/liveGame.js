import http from './http'

// 初始化
export const initBoard = (row, col, liveArray) => {
  return http.get(`/liveGame/init?row=${row}&col=${col}&liveArray=${liveArray}`)
}

// 演化一次
export const nextBoard = () => http.get(`/liveGame/next`)
