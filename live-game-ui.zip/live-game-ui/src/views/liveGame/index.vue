<template>
  <section>
    <div id="board"></div>
    <div id="rightPanel">
      <el-row>
        <el-col style="margin: 20px">
          <el-button type="primary" @click="dialogVisible  = true">初始化</el-button>
        </el-col>
        <el-col style="margin: 20px">
          <el-button type="primary" @click="nextData(false)">开 始</el-button>
        </el-col>
        <el-col style="margin: 20px">
          <el-button type="danger" @click="nextData(true)">重 置</el-button>
        </el-col>
      </el-row>
    </div>
    <el-dialog
      title="棋盘初始化"
      :visible.sync="dialogVisible"
      width="30%">
      <el-input placeholder="棋盘行大小" v-model="row" />
      <el-input placeholder="棋盘列大小" v-model="col"/>
      <el-input placeholder="值都为1的行,逗号分隔" v-model="liveStr"/>
      <span slot="footer" class="dialog-footer">
    <el-button @click="dialogVisible = false">取 消</el-button>
    <el-button type="primary" @click="this.initData">确 定</el-button>
  </span>
    </el-dialog>
  </section>
</template>

<script>
  import {initBoard, nextBoard} from "@/api/liveGame.js"
  export default {
    name: "liveGame",
    data() {
      return {
        dialogVisible: false,
        row: 16,
        col: 16,
        liveStr: undefined,
        timer: undefined,
        boardData: []
      }
    },
    mounted() {
      this.initData();
    },
    methods: {
      async initData() {
        let liveArray = [];
        if (this.liveStr) {
          liveArray = this.liveStr.split(",");
        }
        let res = await initBoard(this.row, this.col, liveArray);
        this.boardData = res.data.data;
        this.rendering();
        this.dialogVisible = false;
      },
      nextData(stopFlag) {
        if (stopFlag) {
          clearInterval(this.timer);
          this.initData();
        } else {
          this.timer = setInterval(() => {
            nextBoard().then(res => {
              this.boardData = res.data.data;
              this.rendering();
            })
          }, 1000);
        }
      },
      rendering() {
        let htmlStr = "<table border='0px'>";

        for(let i = 0; i < this.row; i++) {
          htmlStr += "<tr>";
          for(let j = 0; j < this.col; j++) {
            if (this.boardData[i][j] == 1) {
              htmlStr += "<td style='color: red'> &nbsp;&nbsp;" + this.boardData[i][j] + " </td>";
            } else {
              htmlStr += "<td> &nbsp;&nbsp;" + this.boardData[i][j] + " </td>";
            }
          }
          htmlStr += "</tr>";
        }
        htmlStr += "</table>";
        document.getElementById("board").innerHTML = htmlStr;
      }
    }
  }
</script>

<style scoped>
  #rightPanel {
    position: absolute;
    top: 0;
    bottom: 0;
    right: 0;
    width: 200px;
    border-left: black 1px solid;
    padding-left: 20px;
  }
</style>