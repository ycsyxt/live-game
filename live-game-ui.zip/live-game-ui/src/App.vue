<template>
  <div id="app">
    <live-game />
  </div>
</template>

<script>
  import LiveGame from "./views/liveGame/index";
  export default  {
    name:  'App',
    components: {LiveGame},
  }
</script>